﻿
using Microsoft.AspNetCore.Identity;

namespace OperaWeb.Server.DataClasses
{
    public class ApplicationRole : IdentityRole
    {
    }
}
