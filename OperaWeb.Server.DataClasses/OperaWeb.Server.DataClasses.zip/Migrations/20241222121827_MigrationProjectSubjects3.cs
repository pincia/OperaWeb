﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OperaWeb.Server.DataClasses.Migrations
{
    /// <inheritdoc />
    public partial class MigrationProjectSubjects3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Notifications_AspNetUsers_UserId",
                table: "Notifications");

            migrationBuilder.DropForeignKey(
                name: "FK_ProjectSubjects_AspNetUsers_UserId",
                table: "ProjectSubjects");

            migrationBuilder.DropForeignKey(
                name: "FK_ProjectSubjects_Projects_ProjectId",
                table: "ProjectSubjects");

            migrationBuilder.DropForeignKey(
                name: "FK_VociComputo_Projects_ProjectID",
                table: "VociComputo");

            migrationBuilder.AddForeignKey(
                name: "FK_Notifications_AspNetUsers_UserId",
                table: "Notifications",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ProjectSubjects_AspNetUsers_UserId",
                table: "ProjectSubjects",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ProjectSubjects_Projects_ProjectId",
                table: "ProjectSubjects",
                column: "ProjectId",
                principalTable: "Projects",
                principalColumn: "ID");

            migrationBuilder.AddForeignKey(
                name: "FK_VociComputo_Projects_ProjectID",
                table: "VociComputo",
                column: "ProjectID",
                principalTable: "Projects",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Notifications_AspNetUsers_UserId",
                table: "Notifications");

            migrationBuilder.DropForeignKey(
                name: "FK_ProjectSubjects_AspNetUsers_UserId",
                table: "ProjectSubjects");

            migrationBuilder.DropForeignKey(
                name: "FK_ProjectSubjects_Projects_ProjectId",
                table: "ProjectSubjects");

            migrationBuilder.DropForeignKey(
                name: "FK_VociComputo_Projects_ProjectID",
                table: "VociComputo");

            migrationBuilder.AddForeignKey(
                name: "FK_Notifications_AspNetUsers_UserId",
                table: "Notifications",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ProjectSubjects_AspNetUsers_UserId",
                table: "ProjectSubjects",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.SetNull);

            migrationBuilder.AddForeignKey(
                name: "FK_ProjectSubjects_Projects_ProjectId",
                table: "ProjectSubjects",
                column: "ProjectId",
                principalTable: "Projects",
                principalColumn: "ID",
                onDelete: ReferentialAction.SetNull);

            migrationBuilder.AddForeignKey(
                name: "FK_VociComputo_Projects_ProjectID",
                table: "VociComputo",
                column: "ProjectID",
                principalTable: "Projects",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
