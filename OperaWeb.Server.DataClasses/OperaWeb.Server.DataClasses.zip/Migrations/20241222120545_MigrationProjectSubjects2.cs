﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OperaWeb.Server.DataClasses.Migrations
{
    /// <inheritdoc />
    public partial class MigrationProjectSubjects2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ProjectSubjects_Projects_ProjectId",
                table: "ProjectSubjects");

            migrationBuilder.AddForeignKey(
                name: "FK_ProjectSubjects_Projects_ProjectId",
                table: "ProjectSubjects",
                column: "ProjectId",
                principalTable: "Projects",
                principalColumn: "ID",
                onDelete: ReferentialAction.SetNull);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ProjectSubjects_Projects_ProjectId",
                table: "ProjectSubjects");

            migrationBuilder.AddForeignKey(
                name: "FK_ProjectSubjects_Projects_ProjectId",
                table: "ProjectSubjects",
                column: "ProjectId",
                principalTable: "Projects",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
