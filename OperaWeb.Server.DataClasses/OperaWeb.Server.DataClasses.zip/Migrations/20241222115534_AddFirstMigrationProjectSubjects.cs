﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OperaWeb.Server.DataClasses.Migrations
{
    /// <inheritdoc />
    public partial class AddFirstMigrationProjectSubjects : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_Comuni_ComuneId",
                table: "AspNetUsers");

            migrationBuilder.DropForeignKey(
                name: "FK_ElencoPrezzi_Projects_ProjectID",
                table: "ElencoPrezzi");

            migrationBuilder.DropForeignKey(
                name: "FK_IdentityRoleOrganizationRoleMapping_AspNetRoles_IdentityRoleId",
                table: "IdentityRoleOrganizationRoleMapping");

            migrationBuilder.DropForeignKey(
                name: "FK_IdentityRoleOrganizationRoleMapping_OrganizationRoles_OrganizationRoleId",
                table: "IdentityRoleOrganizationRoleMapping");

            migrationBuilder.DropForeignKey(
                name: "FK_OrganizationMembers_AspNetUsers_OrganizationId",
                table: "OrganizationMembers");

            migrationBuilder.DropForeignKey(
                name: "FK_OrganizationMembers_OrganizationRoles_RoleId",
                table: "OrganizationMembers");

            migrationBuilder.DropPrimaryKey(
                name: "PK_IdentityRoleOrganizationRoleMapping",
                table: "IdentityRoleOrganizationRoleMapping");

            migrationBuilder.RenameTable(
                name: "IdentityRoleOrganizationRoleMapping",
                newName: "OrganizationRoleMappings");

            migrationBuilder.RenameIndex(
                name: "IX_IdentityRoleOrganizationRoleMapping_OrganizationRoleId",
                table: "OrganizationRoleMappings",
                newName: "IX_OrganizationRoleMappings_OrganizationRoleId");

            migrationBuilder.RenameIndex(
                name: "IX_IdentityRoleOrganizationRoleMapping_IdentityRoleId",
                table: "OrganizationRoleMappings",
                newName: "IX_OrganizationRoleMappings_IdentityRoleId");

            migrationBuilder.AlterColumn<int>(
                name: "SubRoleId",
                table: "RoleSubRoles",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int")
                .OldAnnotation("Relational:ColumnOrder", 1);

            migrationBuilder.AlterColumn<string>(
                name: "RoleId",
                table: "RoleSubRoles",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)")
                .OldAnnotation("Relational:ColumnOrder", 0);

            migrationBuilder.AddPrimaryKey(
                name: "PK_OrganizationRoleMappings",
                table: "OrganizationRoleMappings",
                column: "Id");

            migrationBuilder.CreateTable(
                name: "ProjectSubjects",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProjectId = table.Column<int>(type: "int", nullable: false),
                    SubjectName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProjectSubjects", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ProjectSubjects_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "FK_ProjectSubjects_Projects_ProjectId",
                        column: x => x.ProjectId,
                        principalTable: "Projects",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ProjectSubjects_ProjectId",
                table: "ProjectSubjects",
                column: "ProjectId");

            migrationBuilder.CreateIndex(
                name: "IX_ProjectSubjects_UserId",
                table: "ProjectSubjects",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_Comuni_ComuneId",
                table: "AspNetUsers",
                column: "ComuneId",
                principalTable: "Comuni",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ElencoPrezzi_Projects_ProjectID",
                table: "ElencoPrezzi",
                column: "ProjectID",
                principalTable: "Projects",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_OrganizationMembers_AspNetUsers_OrganizationId",
                table: "OrganizationMembers",
                column: "OrganizationId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_OrganizationMembers_OrganizationRoles_RoleId",
                table: "OrganizationMembers",
                column: "RoleId",
                principalTable: "OrganizationRoles",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_OrganizationRoleMappings_AspNetRoles_IdentityRoleId",
                table: "OrganizationRoleMappings",
                column: "IdentityRoleId",
                principalTable: "AspNetRoles",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_OrganizationRoleMappings_OrganizationRoles_OrganizationRoleId",
                table: "OrganizationRoleMappings",
                column: "OrganizationRoleId",
                principalTable: "OrganizationRoles",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_Comuni_ComuneId",
                table: "AspNetUsers");

            migrationBuilder.DropForeignKey(
                name: "FK_ElencoPrezzi_Projects_ProjectID",
                table: "ElencoPrezzi");

            migrationBuilder.DropForeignKey(
                name: "FK_OrganizationMembers_AspNetUsers_OrganizationId",
                table: "OrganizationMembers");

            migrationBuilder.DropForeignKey(
                name: "FK_OrganizationMembers_OrganizationRoles_RoleId",
                table: "OrganizationMembers");

            migrationBuilder.DropForeignKey(
                name: "FK_OrganizationRoleMappings_AspNetRoles_IdentityRoleId",
                table: "OrganizationRoleMappings");

            migrationBuilder.DropForeignKey(
                name: "FK_OrganizationRoleMappings_OrganizationRoles_OrganizationRoleId",
                table: "OrganizationRoleMappings");

            migrationBuilder.DropTable(
                name: "ProjectSubjects");

            migrationBuilder.DropPrimaryKey(
                name: "PK_OrganizationRoleMappings",
                table: "OrganizationRoleMappings");

            migrationBuilder.RenameTable(
                name: "OrganizationRoleMappings",
                newName: "IdentityRoleOrganizationRoleMapping");

            migrationBuilder.RenameIndex(
                name: "IX_OrganizationRoleMappings_OrganizationRoleId",
                table: "IdentityRoleOrganizationRoleMapping",
                newName: "IX_IdentityRoleOrganizationRoleMapping_OrganizationRoleId");

            migrationBuilder.RenameIndex(
                name: "IX_OrganizationRoleMappings_IdentityRoleId",
                table: "IdentityRoleOrganizationRoleMapping",
                newName: "IX_IdentityRoleOrganizationRoleMapping_IdentityRoleId");

            migrationBuilder.AlterColumn<int>(
                name: "SubRoleId",
                table: "RoleSubRoles",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int")
                .Annotation("Relational:ColumnOrder", 1);

            migrationBuilder.AlterColumn<string>(
                name: "RoleId",
                table: "RoleSubRoles",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)")
                .Annotation("Relational:ColumnOrder", 0);

            migrationBuilder.AddPrimaryKey(
                name: "PK_IdentityRoleOrganizationRoleMapping",
                table: "IdentityRoleOrganizationRoleMapping",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_Comuni_ComuneId",
                table: "AspNetUsers",
                column: "ComuneId",
                principalTable: "Comuni",
                principalColumn: "Id",
                onDelete: ReferentialAction.SetNull);

            migrationBuilder.AddForeignKey(
                name: "FK_ElencoPrezzi_Projects_ProjectID",
                table: "ElencoPrezzi",
                column: "ProjectID",
                principalTable: "Projects",
                principalColumn: "ID");

            migrationBuilder.AddForeignKey(
                name: "FK_IdentityRoleOrganizationRoleMapping_AspNetRoles_IdentityRoleId",
                table: "IdentityRoleOrganizationRoleMapping",
                column: "IdentityRoleId",
                principalTable: "AspNetRoles",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_IdentityRoleOrganizationRoleMapping_OrganizationRoles_OrganizationRoleId",
                table: "IdentityRoleOrganizationRoleMapping",
                column: "OrganizationRoleId",
                principalTable: "OrganizationRoles",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_OrganizationMembers_AspNetUsers_OrganizationId",
                table: "OrganizationMembers",
                column: "OrganizationId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_OrganizationMembers_OrganizationRoles_RoleId",
                table: "OrganizationMembers",
                column: "RoleId",
                principalTable: "OrganizationRoles",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
