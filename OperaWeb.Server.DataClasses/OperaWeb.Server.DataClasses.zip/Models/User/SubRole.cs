﻿namespace OperaWeb.Server.DataClasses.Models.User
{
  public class SubRole
  {
    public int ID { get; set; }
    public string Name { get; set; } // Es. Muratore, Falegname
  }
}
