﻿namespace OperaWeb.Server.Models.DTO.Project
{
  public class CreateProjectFromFileRequestDTO
  {
    public IFormFile File { get; set; }

  }
}
