﻿namespace OperaWeb.Server.Models.XPVE
{
    /// <remarks/>
    [Serializable()]
    [System.ComponentModel.DesignerCategory("code")]
    public partial class PweDocumentoPweDatiGeneraliPweDGModuliPweDGAnalisi
    {

        private string speseUtiliField;

        private string speseGeneraliField;

        private string utiliImpresaField;

        private string oneriAccessoriScField;

        private string confQuantitaField;

        /// <remarks/>
        public string SpeseUtili
        {
            get
            {
                return speseUtiliField;
            }
            set
            {
                speseUtiliField = value;
            }
        }

        /// <remarks/>
        public string SpeseGenerali
        {
            get
            {
                return speseGeneraliField;
            }
            set
            {
                speseGeneraliField = value;
            }
        }

        /// <remarks/>
        public string UtiliImpresa
        {
            get
            {
                return utiliImpresaField;
            }
            set
            {
                utiliImpresaField = value;
            }
        }

        /// <remarks/>
        public string OneriAccessoriSc
        {
            get
            {
                return oneriAccessoriScField;
            }
            set
            {
                oneriAccessoriScField = value;
            }
        }

        /// <remarks/>
        public string ConfQuantita
        {
            get
            {
                return confQuantitaField;
            }
            set
            {
                confQuantitaField = value;
            }
        }
    }


}
