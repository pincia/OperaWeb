﻿namespace OperaWeb.Server.Models.XPVE
{
    /// <remarks/>
    [Serializable()]
    [System.ComponentModel.DesignerCategory("code")]
    public partial class PweDocumentoPweDatiGeneraliPweDGConfigurazione
    {

        private PweDocumentoPweDatiGeneraliPweDGConfigurazionePweDGConfigNumeri pweDGConfigNumeriField;

        /// <remarks/>
        public PweDocumentoPweDatiGeneraliPweDGConfigurazionePweDGConfigNumeri PweDGConfigNumeri
        {
            get
            {
                return pweDGConfigNumeriField;
            }
            set
            {
                pweDGConfigNumeriField = value;
            }
        }
    }


}
