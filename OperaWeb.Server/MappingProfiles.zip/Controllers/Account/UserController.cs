using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using OperaWeb.Server.DataClasses;
using OperaWeb.Server.Models.DTO;
using Services;
using Services.UserGroup;
using System.Security.Claims;

namespace OperaWeb.Server.Controllers.Account
{
  [ApiController]
  [Route("api/[controller]/[action]")]
  public class UserController : ControllerBase
  {
    private readonly ILogger<UserController> _logger;
    private readonly UserService _userService;

    public UserController(UserService userService, ILogger<UserController> logger)
    {
      _userService = userService;
      _logger = logger;
    }

    [HttpPost]
    public async Task<AppResponse<object>> Register(UserRegisterRequest req)
    {
      return await _userService.UserRegisterAsync(req, Request.Headers["origin"]);
    }


    [HttpGet]
    public async Task<AppResponse<ApplicationUser>> Me()
    {
      var userId = User.FindFirstValue("Id");

      var user =  await _userService.Me(userId);

      return user;
    }

    [HttpPost]
    public async Task<AppResponse<UserLoginResponse>> Login(UserLoginRequest req)
    {
      _logger.Log(LogLevel.Information, "[UserController] try to log");
      return await _userService.UserLoginAsync(req);
    }

    [HttpPost]
    public async Task<AppResponse<UserRefreshTokenResponce>> RefreshToken(UserRefreshTokenRequest req)
    {
      return await _userService.UserRefreshTokenAsync(req);
    }
    [HttpPost]
    public async Task<AppResponse<bool>> Logout()
    {
      return await _userService.UserLogoutAsync(User);
    }

    [HttpPost]
    [Authorize]
    public string Profile()
    {
      return User.FindFirst("UserName")?.Value ?? "";
    }

    [HttpPost]

    public async Task<AppResponse<bool>> Delete(string userName)
    {
      return await _userService.DeleteUser(userName);
    }

    [AllowAnonymous]
    [HttpGet("verify-email")]
    public IActionResult VerifyEmail(string token)
    {
      _userService.VerifyEmail(token);
      return Ok(new { message = "Verification successful, you can now login" });
    }

    [AllowAnonymous]
    [HttpPost("forgot-password")]
    public IActionResult ForgotPassword(ForgotPasswordRequest model)
    {
      _userService.ForgotPassword(model, Request.Headers["origin"]);
      return Ok(new { message = "Please check your email for password reset instructions" });
    }
  }
}
