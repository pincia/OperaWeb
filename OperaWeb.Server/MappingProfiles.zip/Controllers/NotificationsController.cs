﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using OperaWeb.Server.DataClasses;
using OperaWeb.Server.Models.DTO;

[ApiController]
[Route("api/notifications")]
public class NotificationsController : ControllerBase
{
  private readonly NotificationService _notificationService;
  private readonly UserManager<ApplicationUser> _userManager;

  public NotificationsController(NotificationService notificationService, UserManager<ApplicationUser> userManager)
  {
    _notificationService = notificationService;
    _userManager = userManager;
  }

  // Ottieni notifiche per l'utente autenticato
  [HttpGet]
  public async Task<IActionResult> GetUserNotifications()
  {
    // Recupera l'utente dal token JWT
    var user = await _userManager.GetUserAsync(User);
    if (user == null)
    {
      return Unauthorized(); // Restituisce 401 se non è autenticato
    }

    // Recupera le notifiche collegate all'utente
    var notifications = await _notificationService.GetUserNotificationsAsync(user.Id);
    return Ok(notifications);
  }

  // Segna una notifica come letta
  [HttpPost("mark-as-read/{id}")]
  public async Task<IActionResult> MarkAsRead(int id)
  {
    // Recupera l'utente dal token JWT
    var user = await _userManager.GetUserAsync(User);
    if (user == null)
    {
      return Unauthorized();
    }

    // Verifica che la notifica appartenga all'utente
    var notification = await _notificationService.GetNotificationByIdAsync(id);
    if (notification == null || notification.User.Id != user.Id)
    {
      return Forbid(); // Restituisce 403 se non appartiene all'utente
    }

    await _notificationService.MarkAsReadAsync(id);
    return NoContent();
  }

  // Crea una nuova notifica per l'utente autenticato
  [HttpPost]
  public async Task<IActionResult> CreateNotification([FromBody] NotificationCreateDto dto)
  {
    // Recupera l'utente dal token JWT
    var user = await _userManager.GetUserAsync(User);
    if (user == null)
    {
      return Unauthorized();
    }

    // Crea una notifica associata all'utente
    await _notificationService.AddNotificationAsync(user.Id, dto.Title, dto.Message);
    return CreatedAtAction(nameof(GetUserNotifications), null);
  }
  [HttpPost("mark-all-as-read")]
  public async Task<IActionResult> MarkAllAsRead()
  {
    var user = await _userManager.GetUserAsync(User);
    if (user == null)
    {
      return Unauthorized();
    }

    await _notificationService.MarkAllAsReadAsync(user.Id);

    return NoContent();
  }

}

