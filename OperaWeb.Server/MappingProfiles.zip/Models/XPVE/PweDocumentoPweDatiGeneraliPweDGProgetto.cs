﻿namespace OperaWeb.Server.Models.XPVE
{
    /// <remarks/>
    [Serializable()]
    [System.ComponentModel.DesignerCategory("code")]
    public partial class PweDocumentoPweDatiGeneraliPweDGProgetto
    {

        private PweDocumentoPweDatiGeneraliPweDGProgettoPweDGDatiGenerali pweDGDatiGeneraliField;

        /// <remarks/>
        public PweDocumentoPweDatiGeneraliPweDGProgettoPweDGDatiGenerali PweDGDatiGenerali
        {
            get
            {
                return pweDGDatiGeneraliField;
            }
            set
            {
                pweDGDatiGeneraliField = value;
            }
        }
    }


}
