﻿namespace OperaWeb.Server.Models.XPVE
{
    /// <remarks/>
    [Serializable()]
    [System.ComponentModel.DesignerCategory("code")]
    public partial class PweDocumentoPweDatiGeneraliPweDGModuli
    {

        private PweDocumentoPweDatiGeneraliPweDGModuliPweDGAnalisi pweDGAnalisiField;

        /// <remarks/>
        public PweDocumentoPweDatiGeneraliPweDGModuliPweDGAnalisi PweDGAnalisi
        {
            get
            {
                return pweDGAnalisiField;
            }
            set
            {
                pweDGAnalisiField = value;
            }
        }
    }


}
