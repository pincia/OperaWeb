﻿namespace OperaWeb.Server.Models.DTO.Project
{
    public class DeleteProjectRequestDTO
  {
        public int Id { get; set; }
    }
}
