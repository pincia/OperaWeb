﻿namespace OperaWeb.Server.Models.DTO
{
  public class User
  {
    public string Username { get; set; }
  }
}
