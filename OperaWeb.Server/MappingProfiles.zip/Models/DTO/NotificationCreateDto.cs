﻿namespace OperaWeb.Server.Models.DTO
{
  public class NotificationCreateDto
  {
    public string Title { get; set; }
    public string Message { get; set; }
  }

}
