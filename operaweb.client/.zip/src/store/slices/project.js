﻿// third-party
import { createSlice } from '@reduxjs/toolkit';
import { dispatch } from '../index';

const initialState = {
    error: null,
    currentImportedProject: null 
};

const slice = createSlice({
    name: 'project',
    initialState,
    reducers: {
        // HAS ERROR
        hasError(state, action) {
            state.error = action.payload;
        },

        // SET IMPORTED PROJECT
        setImportedProjectSuccess(state, action) {
            state.currentImportedProject = action.payload;
        },

        // CLEAR IMPORTED PROJECT
        clearImportedProjectSuccess(state) {
            state.currentImportedProject = null;
        }
    }
});

// Reducer
export default slice.reducer;

// ⬇️ this is the redux functions

// Imposta il progetto importato
export function setImportedProject(project) {
    return async () => {
        try {
            dispatch(slice.actions.setImportedProjectSuccess(project));
        } catch (error) {
            dispatch(slice.actions.hasError(error));
        }
    };
}

// Cancella il progetto importato
export function clearImportedProject() {
    return async () => {
        try {
            dispatch(slice.actions.clearImportedProjectSuccess());
        } catch (error) {
            dispatch(slice.actions.hasError(error));
        }
    };
}

