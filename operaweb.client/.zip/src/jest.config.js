module.exports = {
    testEnvironment: 'jsdom', // Ambiente per i test di componenti React
};
