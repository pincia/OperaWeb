import React from 'react';
import { render, screen } from '@testing-library/react';
import { Provider } from 'react-redux';
import configureMockStore from 'redux-mock-store';
import ProjectWizard from 'views/forms/forms-wizard/ProjectWizard';

// Crea un mock store
const mockStore = configureMockStore();

test('renders ProjectWizard with imported project data', () => {
    // Stato mock di Redux
    const testProject = {
        currentImportedProject: {
            DatiGenerali: {
                nome: 'Progetto di test',
                descrizione: 'Descrizione di test',
                dataCreazione: '2024-01-01'
            }
        }
    };

    const store = mockStore({ projects: testProject });

    // Renderizza il componente avvolto nel Provider Redux
    render(
        <Provider store={store}>
            <ProjectWizard />
        </Provider>
    );

    // Aspettati che i dati del progetto vengano visualizzati
    expect(screen.getByText(/Wizard Creazione Progetto/i)).toBeInTheDocument();
    expect(screen.getByText(/Progetto di test/i)).toBeInTheDocument();
});
