const axios = jest.createMockFromModule('axios');

axios.create = jest.fn(() => axios);

export default axios;
